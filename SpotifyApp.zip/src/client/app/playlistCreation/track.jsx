import React from 'react';

class Track extends React.Component {
    constructor(props){
        super(props);
    }

    render() {
        return (
            <div></div>
        )
    }
}

export default Tracks;