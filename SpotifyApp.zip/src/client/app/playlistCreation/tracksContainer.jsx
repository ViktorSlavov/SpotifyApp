import React from 'react';
import Track from './track.jsx';

class TracksContainer extends React.Component {
    constructor(props){
        super(props);
    }

    render() {
        return (
            <div></div>
        )
    }
}

export default TracksContainer;