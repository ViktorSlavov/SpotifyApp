//Optional component; We may not need it, depends on the way search renders the results;

import React from 'react';

class SearchEntry extends React.Component {
    constructor(props){
        super(props);
        
    }

    render(){
        return (
            <div></div>
        )
    }
}

export default SearchEntry;