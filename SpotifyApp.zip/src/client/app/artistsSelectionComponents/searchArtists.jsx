import React from 'react';
import SearchEntry from './searchEntry.jsx';


class SearchArtists extends React.Component {
    constructor(props){
        super(props);
        
    }

    render(){
        return (
            <div></div>
        )
    }
}

export default SearchArtists;